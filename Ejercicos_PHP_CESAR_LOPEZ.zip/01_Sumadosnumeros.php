<?php
    $SB = 650000;
    $V1 = 100000;
    $V2 = 120000;
    $V3 = 300000;

    $VT=$V1+$V2+$V3;
    $COM=($VT*0.10);
    $TG = $SB+$COM;

    echo "EL SUELDO BASE ES DE $SB";
    echo "<BR> LA VENTA 1 ES DE $V1";
    echo "<BR> LA VENTA 2 ES DE $V2";
    echo "<BR> LA VENTA 3 ES DE $V3";
    echo "<BR> EL TOTAL DE LA VENTAS ES $VT";
    echo "<BR> LA COMISION ES DE  $COM";
    echo "<BR> LO QUE GANA EN EL MES ES:  $TG";

?>