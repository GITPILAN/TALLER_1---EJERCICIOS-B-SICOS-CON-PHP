<?php

    $capital=1000;
    $tasa_mensual=0.02;
    $NuevoCapital=$capital+($capital*$tasa_mensual);

    echo "Capital inicial: $capital, ";
    echo "<br>Tasa mensual: 2%, ";
    echo "<br>Nuevo capital: $NuevoCapital";


?>