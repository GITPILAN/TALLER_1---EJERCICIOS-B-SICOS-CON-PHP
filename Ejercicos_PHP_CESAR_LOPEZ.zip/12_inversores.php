<?php

    $inversor1=50;
    $inversor2=50;
    $inversor3=25;
    $totalcapital=$inversor1+$inversor2+$inversor3;
    
    echo "TOTAL CAPITAL INVERTIDO : $totalcapital   ";
    echo "<br> Porcentaje participacion INVERSOR 1 es ".(($inversor1/$totalcapital)*100)."% ";
    echo "<br> Porcentaje participacion INVERSOR 2 es ".(($inversor2/$totalcapital)*100)."% ";
    echo "<br> Porcentaje participacion INVERSOR 3 es ".(($inversor3/$totalcapital)*100)."% ";


?>