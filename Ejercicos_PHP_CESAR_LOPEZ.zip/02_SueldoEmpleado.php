<?php
    $s=500000;
    $SN=$s+($s*0.10);
    echo "EL SUELDO ACTUAL ES = $s";
    echo "<br>Aumento del 10%";
    echo "<br>EL SUELDO NUEVO DE EMPLEADO ES = $SN";
?>