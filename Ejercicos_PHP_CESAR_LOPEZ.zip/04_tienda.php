<?php

    $precio=100;
    $descuento=0.25;
    $totalPagar=$precio-($precio*$descuento);

    echo "Total a Pagar por cliente es: $totalPagar";


?>