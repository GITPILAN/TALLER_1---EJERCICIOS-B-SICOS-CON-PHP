<?php

  $n1=3;
  $n2=2;
  $n3=4;
  echo "el cuadrado de $n1 es igual a: ".$n1*$n1." | ";
  echo "<br> el cuadrado de $n2 es igual a: ".$n2*$n2." | ";
  echo "<br> el cuadrado de $n3 es igual a: ".$n3*$n3." | ";
  

?>