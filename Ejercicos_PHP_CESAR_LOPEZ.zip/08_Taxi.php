<?php

  $Tarifa_taxi = 15.00;
  $Tarifa_minuto = 2.00;

  $Km_recorrido = 5;
  $Tiempo_recorrido= 10;

  $Total_pagar = ($Km_recorrido*$Tarifa_taxi)+($Tiempo_recorrido*$Tarifa_minuto);

  Echo "Total a pagar por recorrido en $Km_recorrido KM y $Tiempo_recorrido Minutos es: $Total_pagar";


?>