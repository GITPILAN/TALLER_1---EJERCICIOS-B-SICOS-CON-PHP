<?php

  $Total_presupuesto_hospital = 100000;
  $porcentaje_ginecologia= 0.40;
  $porcentaje_traumatologia= 0.30;
  $porcentaje_pediatria= 0.30;

    echo "TOTAL PRESUPUESTO DEL HOSPITAL: ".$Total_presupuesto_hospital." | ";
    echo "<br> a Ginecologia le corresponde el 40% que es igual a: ".$porcentaje_ginecologia*$Total_presupuesto_hospital." | ";
    echo "<br> a Traumatologia le corresponde el 30% que es igual a: ".$porcentaje_traumatologia*$Total_presupuesto_hospital." | ";
    echo "<br> a Pediatria le corresponde el 30% que es igual a: ".$porcentaje_pediatria*$Total_presupuesto_hospital." | ";
  

?>