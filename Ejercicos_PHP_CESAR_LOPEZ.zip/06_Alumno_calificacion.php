<?php
    

    $promedio = 18;
    $examen_final = 14;
    $trabajo_final = 18;

    $calificacion = (($promedio*0.55)+($examen_final*0.30)+($trabajo_final*0.15));

    echo "La califiacion del alumnoa en ALGORITMO es: $calificacion";



?>