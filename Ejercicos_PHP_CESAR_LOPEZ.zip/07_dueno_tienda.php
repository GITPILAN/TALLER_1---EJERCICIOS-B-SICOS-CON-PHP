<?php

    $precio_compra=1000;
    $Precio_venta=$precio_compra+($precio_compra*.30);
    echo "Debe vender el articulo en: $Precio_venta";

?>